<?php

class V1_Model extends Model
{
    public function __construct()
    {
        parent::__construct();
    }

    function command($o, $tbl, $data = false, $id = false)
    {
        switch ($o) {
            case "count":
                return $this->db->select("select count(`$tbl[1]`) as `total` from `$tbl[0]`;");
            case "fetch":
                return $this->db->select("select * from `$tbl[0]`");
            case "delete":
                return $this->db->delete("$tbl[0]", "`$tbl[1]`='$id'");
            case "insert":
                return $this->db->insert("$tbl[0]", $data);
            case "info":
                return $this->db->select("select * from `$tbl[0]` where `$tbl[1]`=:id", [':id' => $id]);
            case "update":
                return $this->db->update("$tbl[0]", $data, "`$tbl[1]`='{$id}'");
            default:
                die("O is unknown!");
        }
    }

    function jData($issn)
    {
        return $this->db->select("SELECT * FROM `scimagojr` WHERE `Issn` LIKE '%$issn%' limit 1");
    }

    function jcr($issn)
    {
        return $this->db->select("SELECT * FROM `jcr` WHERE `ISSN` LIKE '%$issn%' limit 1");
    }



    function car()
    {
        return $this->db->select("SELECT * FROM `car` WHERE `status`=:status AND `trackable`=:trackable", [':trackable' => 1, ':status' => 1]);
    }

    ////////////////////////////////
    //////////////////////////////// //////////////////////////////// ////////////////////////////////
    ////////////////////////////////
    //////////////////////////////// //////////////////////////////// ////////////////////////////////
    ////////////////////////////////

    public function dashboard()
    {
        return $data = [
            'request' =>  $this->db->select('SELECT COUNT(*) as `total` FROM `p_request` WHERE `status`=:status;', [':status' => 0])[0]['total'],
            'engineer' =>  $this->db->select('SELECT COUNT(*) as `total` FROM `p_request` WHERE `status`=:status;', [':status' => 1])[0]['total'],
            'commission' =>  $this->db->select('SELECT COUNT(*) as `total` FROM `p_request` WHERE `status`=:status;', [':status' => 2])[0]['total'],
            'accept' =>  $this->db->select('SELECT COUNT(*) as `total` FROM `p_request` WHERE `status`=:status;', [':status' => 3])[0]['total'],
            'decline' =>  $this->db->select('SELECT COUNT(*) as `total` FROM `p_request` WHERE `status`=:status;', [':status' => 4])[0]['total'],
            'suspend' =>  $this->db->select('SELECT COUNT(*) as `total` FROM `p_request` WHERE `status`=:status;', [':status' => 5])[0]['total'],
            'request_total' =>  $this->db->select('SELECT COUNT(*) as `total` FROM `p_request`',)[0]['total'],
            'proceedings_total' =>  $this->db->select('SELECT COUNT(*) as `total` FROM `p_proceedings`',)[0]['total'],
            'today_request_total' =>  $this->db->select('SELECT COUNT(*) as `total` FROM `p_request` where `dt` LIKE "%' . jdate("Y-m-d", time(), '', '', 'en') . '%"')[0]['total'],
            'commission_total' =>  $this->db->select('SELECT COUNT(*) as `total` FROM `p_commission`',)[0]['total'],
        ];
    }

    function request($tbl, $data, $start = 0, $count = 10)
    {
        $q = '';
        $first = false;
        if (isset($data->id) && !empty($data->id)) {
            if ($first)
                $q .= " AND r.`id` = '" . $data->id . "'";
            else
                $q .= "WHERE r.`id` = '" . $data->id . "'";

            $first = true;
        }

        if (isset($data->fullname) && !empty($data->fullname)) {
            if ($first)
                $q .= " AND r.`fullname` like '%" . $data->fullname . "%'";
            else
                $q .= "WHERE r.`fullname` like '%" . $data->fullname . "%'";

            $first = true;
        }

        if (isset($data->status) && $data->status !== "") {
            if ($first)
                $q .= " AND r.`status` = '" . $data->status . "'";
            else
                $q .= "WHERE r.`status` = '" . $data->status . "'";

            $first = true;
        }

        if (isset($data->p_request_type_id) && !empty($data->p_request_type_id)) {
            if ($first)
                $q .= " AND r.`p_request_type_id` = '" . $data->p_request_type_id . "'";
            else
                $q .= "WHERE r.`p_request_type_id` = '" . $data->p_request_type_id . "'";

            $first = true;
        }

        if (isset($data->accepted_name) && !empty($data->accepted_name)) {
            if ($first)
                $q .= " AND r.`accepted_name` = '" . $data->accepted_name . "'";
            else
                $q .= "WHERE r.`accepted_name` = '" . $data->accepted_name . "'";

            $first = true;
        }

        if (isset($_GET['page']) && !empty($_GET['page']) && is_numeric($_GET['page'])) $start = --$_GET['page'] * $count;

        $r = [
            'list' => $this->db->select("
              SELECT
                 r.*,
                 rt.`name` as `request_type_name`
              FROM
                  `p_request` r
                  inner join `p_request_type` rt on
                  rt.`id` = r.p_request_type_id
              $q
              ORDER BY r.`id` DESC
              LIMIT $start, $count;"),
            'total' => $this->db->select("select count(`id`) as `total` from `p_request` r  $q;")[0]['total']
        ];

        return $r;
    }

    function requestFiltered($data)
    {
        return $this->db->select("
        SELECT
           r.*,
           rt.`name` as `request_type_name`
        FROM
            `p_request` r
            inner join `p_request_type` rt on
            rt.`id` = r.p_request_type_id

            WHERE r.`id` IN (" . $data->request_list . ")");
    }

    function updateRequestFormContent($tbl, $data, $id)
    {
        $data = [
            "form_content" => $data
        ];

        return $res = $this->command('update', $tbl, $data, $id);
    }


    function proceedings($tbl, $data, $start = 0, $count = 10)
    {
        $q = '';
        $first = false;
        if (isset($data->id) && !empty($data->id)) {
            if ($first)
                $q .= " AND p.`id` = '" . $data->id . "'";
            else
                $q .= "WHERE p.`id` = '" . $data->id . "'";

            $first = true;
        }

        if (isset($data->request_id) && !empty($data->request_id)) {
            if ($first)
                $q .= " AND JSON_SEARCH(JSON_EXTRACT(`request_list`, '$[*]'), 'one','$data->request_id') IS NOT NULL";
            else
                $q .= "WHERE  JSON_SEARCH(JSON_EXTRACT(`request_list`, '$[*]'), 'one','$data->request_id') IS NOT NULL";

            $first = true;
        }

        if (isset($_GET['page']) && !empty($_GET['page']) && is_numeric($_GET['page'])) $start = --$_GET['page'] * $count;

        $r = [
            'list' => $this->db->select("
              SELECT
                p.*
              FROM
                  `p_proceedings` p
              $q
              ORDER BY p.`id` DESC
              LIMIT $start, $count;"),
            'total' => $this->db->select("select count(`id`) as `total` from `p_proceedings` p $q;")[0]['total']
        ];

        return $r;
    }


    function final_proceedings($id)
    {

        $proceedings =  $this->db->select("
SELECT
p.*
FROM
`p_proceedings` p
WHERE
p.id = :id", [":id" => $id]);

        $requests = implode(",", json_decode($proceedings[0]['request_list']));
        //==============
        $request_list =  $this->db->select("
SELECT
r.*
FROM
`p_request` r
WHERE
r.id IN ($requests)");
        //==============

        $sign_list =  $this->db->select("
SELECT
rc.*
FROM
`p_request_commission` rc
WHERE
rc.p_request_id IN ($requests)");

        $sign_list_ids = '';
        foreach ($sign_list as $key => $value) {
            $sign_list_ids .= $value['p_commission_id'] . ',';
        }
        $sign_list_ids = substr($sign_list_ids, 0, strlen($sign_list_ids) - 1);
        //==============
        if (!empty($sign_list_ids)) {
            $commission_list =  $this->db->select("
SELECT
c.*
FROM
`p_commission` c
WHERE
c.id IN ($sign_list_ids) 
Order by c.priority asc");
        } else {
            $commission_list = [];
        }
        //==============
        $data = [
            "proceedings" =>   $proceedings,
            "requests" => $request_list,
            "sign_list" => $sign_list,
            "commission_list" => $commission_list,
            "d" => $sign_list_ids
        ];
        return $data;
    }


    function layer($tbl, $data, $start = 0, $count = 10)
    {
        $q = '';
        $first = false;
        if (isset($data->id) && !empty($data->id)) {
            if ($first)
                $q .= " AND l.`id` = '" . $data->id . "'";
            else
                $q .= "WHERE l.`id` = '" . $data->id . "'";

            $first = true;
        }

        if (isset($data->fullname) && !empty($data->fullname)) {
            if ($first)
                $q .= " AND l.`fullname` like '%" . $data->fullname . "%'";
            else
                $q .= "WHERE l.`fullname` like '%" . $data->fullname . "%'";

            $first = true;
        }

        if (isset($data->status) && $data->status !== "") {
            if ($first)
                $q .= " AND r.`status` = '" . $data->status . "'";
            else
                $q .= "WHERE r.`status` = '" . $data->status . "'";

            $first = true;
        }

        if (isset($data->p_request_type_id) && !empty($data->p_request_type_id)) {
            if ($first)
                $q .= " AND l.`p_request_type_id` = '" . $data->p_request_type_id . "'";
            else
                $q .= "WHERE l.`p_request_type_id` = '" . $data->p_request_type_id . "'";

            $first = true;
        }

        if (isset($data->name) && !empty($data->name)) {
            if ($first)
                $q .= " AND l.`name` = '" . $data->name . "'";
            else
                $q .= "WHERE l.`name` = '" . $data->name . "'";

            $first = true;
        }



        if (isset($_GET['page']) && !empty($_GET['page']) && is_numeric($_GET['page'])) $start = --$_GET['page'] * $count;


        $r = [
            'list' => $this->db->select("
              SELECT
                 l.*,
                 rt.`id` as `request_type_id`,
                 rt.`name` as `request_type_name`,
                 rt.`color` as `color`
              FROM
                  `p_layer` l
                inner join `p_request_type` rt on
                  rt.`id` = l.p_request_type_id
              $q
              ORDER BY l.`id` DESC
              LIMIT $start, $count;"),
            'total' => $this->db->select("select count(`id`) as `total` from `p_layer` l  $q;")[0]['total']
        ];

        return $r;
    }
    function saveFormContent($data)
    {
        $form_content = $data->form_content;
        $ids = $data->ids;

        $res = $this->db->select("
              update `p_request` set `form_content`=:content
              where `id` in (" . $ids . ")
              ", [':content' => $form_content]);

        return true;
    }
    function updateLayer($data, $id)
    {
        $res = $this->db->select("
              update `p_layer` set `p_request_type_id`=:type, name=:name
              where `id` in (" . $id . ")
              ", [':type' => $data->p_request_type_id, ':name' => $data->name]);

        return true;
    }


    function uploadRequestDoc($file, $id, $field)
    {
        return $this->db->update('p_request', [$field => $file], "id = '$id'");
    }
    function passageList($tbl)
    {
        return $this->db->select("
             select * from p_request where `tel`=:tel order by `id` desc
              ", [':tel' => $_GET['mobile']]);
    }

    function passageEdit($tbl)
    {
        return $this->db->select("
             select * from p_request where `id`=:id limit 1
              ", [':id' => $_GET['id']]);
    }

    function allLayer()
    {
        return $this->db->select("
              SELECT
                 l.*,
                 rt.`name` as `request_type_name`,
                 rt.`color` as `color`
              FROM
                  `p_layer` l
                inner join `p_request_type` rt on
                  rt.`id` = l.p_request_type_id
              ORDER BY l.`id` DESC");
    }

    function tile()
    {
        return [
            "list" =>  $this->db->select("SELECT * FROM `p_tile`"),
            "group" =>  $this->db->select("
          SELECT
    *
FROM
    `p_tile`
GROUP BY
    `group`
ORDER BY
    id ASC;
          ")
        ];
    }
    function robotQuery($tbl)
    {
        return $this->db->select("
        SELECT *, count(name) as `duplicated_count` FROM `p_layer` 
group by name
HAVING 
    (COUNT(name)>1)
    ORDER by `duplicated_count` DESC
      ");
    }


    function requestCommission()
    {
        //explode(',',$_GET['date'])
        return $this->db->select('
        SELECT
        r.*,
r.p_request_type_id,
r.accepted_name,
rt.name as `request_type_name`,
r.dt
    FROM `p_request` r
    inner join `p_request_type` rt on
    rt.id = r.p_request_type_id
      ');
    }


    function requestDetail($tbl, $id)
    {
        return [
            'request' => $this->db->select("
            SELECT
               r.*,
               rt.`name` as `request_type_name`             
            FROM
                `p_request` r
                inner join `p_request_type` rt on
                rt.`id` = r.p_request_type_id
          WHERE r.id = :id 
            ORDER BY r.`id` DESC
          LIMIT 1", [':id' => $id]),
            'request_commission' => $this->db->select("
          SELECT
             COUNT(*) as `total`             
          FROM
              `p_request_commission` rc
        WHERE `p_request_id` = :id 
        LIMIT 1", [':id' => $id])
        ];
    }
    function requestCommissionDetail($tbl, $id)
    {
        return  $this->db->select("
        SELECT

    c.fullname as `commission_fullname`,
    c.side as `commission_side`,
    c.signature as `commission_signature`
FROM
    `p_request_commission` rc
INNER join `p_request` r on
r.id = rc.p_request_id
INNER join `p_commission` c on
c.id = rc.p_commission_id
where rc.p_request_id = :id
order by c.priority asc
           ", [':id' => $id]);
    }
    function printData($tbl)
    {
        return  $this->db->select("SELECT * FROM `print_data`");
    }

    function requestDetailConfirmation($tbl, $ids, $token)
    {
        $commission =  $this->db->select("
            SELECT
               *
            FROM
                `p_commission` c
          WHERE c.token = :token 
            ORDER BY c.`id` DESC
          LIMIT 1", [':token' => $token]);

        $proceeding =  $this->db->select("
        SELECT
        *
    FROM
        `p_proceedings`
    WHERE
        JSON_CONTAINS(`request_list`, '$ids', '$')");

        return [
            'request' => $this->db->select("
            SELECT
            r.*,
            rc.dt as `sign_date`
        FROM
            `p_request` r
            left join `p_request_commission` rc
            on r.id = rc.p_request_id and rc.p_commission_id=:commission_id
           
        WHERE
            r.id IN($ids)
        ORDER BY
            r.`id`
        DESC", [':commission_id' => $commission[0]['id']]),
            'commission' => $commission,
            'proceeding' =>  $proceeding
        ];
    }

    function commission($tbl, $start = 0, $count = 10)
    {
        if (isset($_GET['page']) && !empty($_GET['page']) && is_numeric($_GET['page'])) $start = --$_GET['page'] * $count;

        $r = [
            'list' => $this->db->select("
              SELECT
                 *
              FROM
                  `p_commission` r
              ORDER BY r.`id` DESC
              LIMIT $start, $count;"),
            'total' => $this->db->select("select count(`id`) as `total` from `p_commission`;")[0]['total']
        ];
        return $r;
    }

    function category($tbl, $start = 0, $count = 10)
    {
        if (isset($_GET['page']) && !empty($_GET['page']) && is_numeric($_GET['page'])) $start = --$_GET['page'] * $count;

        $r = [
            'list' => $this->db->select("
              SELECT
                 c.*
              FROM
                  `p_category` c
              ORDER BY c.`id` DESC
              LIMIT $start, $count;"),
            'total' => $this->db->select("select count(`id`) as `total` from `p_category`;")[0]['total']
        ];
        return $r;
    }

    function requestTypeFilter($tbl)
    {
        return $this->db->select("
        select * from p_request_type where people_can='1'
        ");
    }


    function checkSignatureCount($request_id, $commission_id)
    {
        return $this->db->select("
            SELECT
                *
            FROM
                `p_request_commission` rc
      where p_request_id =:p_request_id and p_commission_id =:p_commission_id 
            ", [
            ':p_request_id' => $request_id,
            ':p_commission_id' => $commission_id
        ]);
    }


    function report($tbl)
    {
        return [
            'r1' => $this->db->select("
            SELECT
                rt.name,
                COUNT(rt.id) as totalRecord
            FROM
                `p_layer` l
                INNER join `p_request_type` rt on 
                l.p_request_type_id = rt.id
               
            group by rt.id")
        ];
    }



    function reportAllRequest($data)
    {


        $q = '';
        $first = false;
        if (isset($data->start_date) && !empty($data->start_date) && isset($data->end_date) && !empty($data->end_date)) {
            if ($first)
                $q .= " AND r.`dt` between '" . $data->start_date . "' and '" . $data->end_date . "'";
            else
                $q .= "WHERE r.`dt` between '" . $data->start_date . "' and '" . $data->end_date . "'";

            $first = true;
        }

        if (isset($data->request_type) && !empty($data->request_type)) {
            if ($first)
                $q .= " AND r.`p_request_type_id` IN (" . $data->request_type . ")";
            else
                $q .= "WHERE r.`p_request_type_id` IN (" . $data->request_type . ")";

            $first = true;
        }

        if (isset($data->category) && !empty($data->category)) {
            if ($first)
                $q .= " AND r.`category_id` IN (" . $data->category . ")";
            else
                $q .= "WHERE r.`category_id` IN (" . $data->category . ")";

            $first = true;
        }

        if (isset($data->status) && !empty($data->status)) {
            if ($first)
                $q .= " AND r.`status` IN (" . $data->status . ")";
            else
                $q .= "WHERE r.`status` IN (" . $data->status . ")";

            $first = true;
        }

        // echo $q;die;


        $result = $this->db->select("
SELECT
   r.*,
   rt.name as   `request_type_name`
FROM
    `p_request` r
    INNER join `p_request_type` rt on 
    r.p_request_type_id = rt.id
$q
    order by r.`dt`
");
        return  $result;
    }




    function requestSend($data)
    {
        $data = (object) $data;

        $this->db->insert('p_request', [
            'p_request_type_id' => $data->request_type_id,
            'fullname' => $data->fullname,
            'address' => $data->address,
            'address_location' => $data->address_location,
            'tel' => $data->tel,
            'title' => $data->title,
            'name' => $data->name,
            'layer' => $data->layer,
            'dt' => jdate('Y-m-d H:i:s', time(), '', '', 'en'),
            'suggestion_names' => $data->suggestion_names,
        ]);
        return $this->db->lastInsertId();
    }

    public function subscription($data)
    {
        $count = $this->command('count', ['subscription', 'id']);
        if (is_array($count) && $count[0]['total'] < 10) {
            $data = $this->db->select(
                "INSERT INTO `subscription`(`ip`, `push_subscription`) VALUES(:ip,:push_subscription)",
                [':ip' => $data['ip'], ':push_subscription' => $data['push_subscription']]
            );
            return $this->db->lastInsertId();
        }
        return '';
    }



    public function allLink($id)
    {
        $data = $this->db->select('SELECT * FROM `link` WHERE `status`=:status ORDER BY `priority` ASC', [':status' => 1]);
        if (is_array($data) && !empty($data))
            return $data;
        else
            return 0;
    }
}
