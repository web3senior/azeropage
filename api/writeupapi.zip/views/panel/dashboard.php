<?php
$data = $this->data;
(new Session)->init();
$admin_information = (new Session)->get('adminInfo');

function _statisticsCard($name, $value, $icon, $size = 2, $gradient = '')
{
    return '<div class="ms-Grid-col ms-sm12 ms-md' . $size . '">
    <div class="card">
        <div class="card-body d-flex flex-column align-items-left" style="' . $gradient . '">
        <i class="goldtext ms-Icon ms-Icon--' . $icon . ' ms-fontSize-28" aria-hidden="true"></i>
       <span class="ms-fontSize-24 ms-fontWeight-bold mt-20">' . $value . '</span>
        <span class="mt-10">' . $name . '</span>
		</div>
	</div>
</div>';
}

//number_format(($data['totalOfCashbox'][0]['sum'] ? $data['totalOfCashbox'][0]['sum'] : 0), 2, '.', ',')
// $chartData = [];
// foreach ($data['driver_chart'] as $key => $value) {
//     array_push($chartData, [$value['education_name'], $value['total']]);
// }

// $statusChartData = [];
// foreach ($data['status_chart'] as $key => $value) {
//     switch ($value['status']) {
//         case 'accepted':
//             $statusText = 'پذیرفته شده';
//             break;
//         case 'pending':
//             $statusText = 'در حال انتظار';
//             break;
//         case 'cancelled':
//             $statusText = 'لغو شده';
//             break;
//         case 'done':
//             $statusText = 'اتمام سفر';
//             break;
//         default:
//             $statusText = 'مشخص نشده';
//             break;
//     }
//     array_push($statusChartData, [$statusText, $value['total']]);
// }
?>
<section class="dashboard">
    <div class="__frame">
        <div class="ms-Grid">
            <div class="ms-Grid-row">
                <div class="ms-Grid-col ms-sm12">
                    <div class="card">
                        <div class="card-header">
                            <i class="ms-Icon ms-Icon--Car ms-fontSize-16" aria-hidden="true"></i>
                            <span class="v-m">5 سفارش آخر</span>
                        </div>
                        <div class="card-body">

                            <?php
                            foreach ($data['last_invoices'] as $key => $value) {
                            ?>
                                <div class="alert alert--dark">
                                    <ul>
                                        <li>نام و نام خانوادگی: <?=$value['fullname']?></li>
                                        <li>جمع کل پرداختی: <?=number_format($value['amount'])?></li>
                                        <li>موبایل: <?=$value['mobile']?></li>
                                        <li>آدرس: <?=$value['address']?></li>
                                    </ul>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <?= _statisticsCard('دسته بندی', $data['category'][0]['total'], 'ContactCard', 6, '') ?>
                <?= _statisticsCard('محصولات', $data['food'][0]['total'], 'BranchCompare', 6, '') ?>
                <?= _statisticsCard('اسلایدر', $data['tour'][0]['total'], 'Contact', 3, '') ?>
                <?= _statisticsCard('کل تراکنش ها', $data['invoiceAll'][0]['total'], 'Slideshow', 3, '') ?>
                <?= _statisticsCard('تراکنش های موفق', $data['invoiceSuccess'][0]['total'], 'Slideshow', 3, '') ?>
                <?= _statisticsCard('تراکنش های موفق', $data['invoiceFailed'][0]['total'], 'Slideshow', 3, '') ?>

                <!-- <div class="ms-Grid-col ms-sm6">
                    <div class="card">
                        <div class="card-header">
                            <i class="ms-Icon ms-Icon--Settings ms-fontSize-16" aria-hidden="true"></i>
                            <span class="v-m">پیکربندی مقاطع تحصیلی</span>
                        </div>
                        <div class="card-body">
                            <a href="<?= URL ?>panel/education">
                                <button>مشاهده و ویرایش</button>
                            </a>
                        </div>
                    </div>
                </div> -->

            </div>
        </div>
    </div>
</section>

<script type="text/javascript">
    // Load the Visualization API and the corechart package.
    google.charts.load('current', {
        'packages': ['corechart']
    });

    // Set a callback to run when the Google Visualization API is loaded.
    google.charts.setOnLoadCallback(drawChart);

    // Callback that creates and populates a data table,
    // instantiates the pie chart, passes in the data and
    // draws it.
    function drawChart() {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Topping');
        data.addColumn('number', 'Slices');
        data.addRows(<?= json_encode($chartData) ?>);

        // Instantiate and draw our chart, passing in some options.
        var chart = new google.visualization.PieChart(document.getElementById('driverChart'));
        chart.draw(data, {
            width: '100%',
            height: 400,
            legend: 'top',
            title: 'رانندگان',
            colors: ['deeppink', '#045356', 'orange'],
            is3D: true,
            fontName: 'Vazir',
            legend: {
                alignment: 'center',
                position: 'right',
                textStyle: {
                    bold: true
                }
            }
        })
        //------------------------------------------------------------------------------------
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Topping');
        data.addColumn('number', 'Slices');
        data.addRows(<?= json_encode($statusChartData) ?>);

        var chart = new google.visualization.PieChart(document.getElementById('statusChart'));
        chart.draw(data, {
            width: '100%',
            height: 400,
            title: 'سفرها',
            colors: ['orange', 'royalblue', 'red', 'green'],
            is3D: true,
            fontName: 'Vazir',
            legend: {
                alignment: 'center',
                position: 'right',
                textStyle: {
                    bold: true
                }
            }
        })

    }
</script>