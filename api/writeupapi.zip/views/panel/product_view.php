<?php
$data = $this->data['driver'][0];
$gender = ($data['gender']) ? 'آقای' : 'خانم';
$car = $this->data['car'];
$comment = $this->data['request'];
$request = $this->data['request'];

$driverRequestStatus = [];
foreach ($request as $key => $value) {
    switch ($value['status']) {
        case 'accepted':
            $statusText = 'پذیرفته شده';
            break;
        case 'pending':
            $statusText = 'در حال انتظار';
            break;
        case 'cancelled':
            $statusText = 'لغو شده';
            break;
        case 'done':
            $statusText = 'اتمام سفر';
            break;
        default:
            $statusText = 'مشخص نشده';
            break;
    }
    array_push($driverRequestStatus, [$statusText, $value['total']]);
}
?>
<section>
    <div class="__frame" data-width="large">
    <p class="alert alert--warning">این قسمت برای مشاهده اطلاعات می باشد، برای ویرایش لطفا از صفحه رانندگان اقدام نمائید</p>
    <p class="alert alert--info">برای مشاهده مدارک آپلود شده به این راننده از قسمت رانندگان اقدام نمائید</p>
        <div class="ms-Grid-row">
            <div class="ms-Grid-col ms-sm12 ms-md12 ms-lg12">
                <div class="card">
                    <div class="card-header">
                        <ul class="d-flex justify-content-between align-items-center">
                            <li>اطلاعات راننده</li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <div class="ms-Grid-row">
                            <div class="ms-Grid-col ms-sm12 ms-md12 ms-lg6">
                                <ul class="d-flex flex-column justify-content-between align-items-start" style="row-gap: 1rem">
                                    <li>
                                        <b>شناسه راننده:</b>
                                        <span class="badge badge-pill badge-danger"><?= $data['id'] ?></span>
                                    </li>
                                    <li>
                                        <b>نام و نام خانوادگی:</b>
                                        <span><?= $gender . ' ' . $data['fullname'] ?></span>
                                    </li>
                                    <li>
                                        <b>نام پدر:</b>
                                        <span> <?= $data['father_name'] ?></span>
                                    </li>
                                    <li>
                                        <b>تلفن:</b>
                                        <span><?= $data['tel'] ?></span>
                                    </li>
                                    <li>
                                        <b>موبایل:</b>
                                        <span><?= $data['mobile'] ?></span>
                                    </li>
                                    <li>
                                        <b>آدرس:</b>
                                        <span><?= $data['address'] ?></span>
                                    </li>
                                    <li>
                                        <b>توضیحات:</b>
                                        <span><?= $data['description'] ?></span>
                                    </li>
                                    <li>
                                        <b>تاریخ درج در سیستم:</b>
                                        <span dir="ltr"><?= jdate('Y-m-d H:i:s', strtotime($data['dt']), '', '', 'en') ?></span>
                                    </li>
                                    <li>
                                        <b>وضیت:</b>
                                        <span dir="ltr"><?= ($data['status']) ? 'فعال' : 'غیرفعال'; ?></span>
                                    </li>
                                </ul>
                            </div>

                            <div class="ms-Grid-col ms-sm12 ms-md12 ms-lg6 d-flex justify-content-end">
                                <figure class="border border-info" style="width:300px;height:300px;background-color:#e3e3e3">
                                    <img src="<?= URL . UPLOAD_IMAGE_PATH . $data['picture'] ?>" alt="" srcset="">
                                </figure>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        لیست خودرو های ثبت شده به این راننده
                    </div>
                    <div class="card-body">

                        <div class="table-responsive">
                            <table class="table table-alternate">
                                <caption></caption>
                                <thead>
                                    <th>ردیف</th>
                                    <th>نام ماشین</th>
                                    <th>مدل</th>
                                    <th>پلاک</th>
                                </thead>
                                <?php
                                foreach ($car as $key => $value) {
                                ?>
                                    <tr class="text-center">
                                        <td><?= ++$key ?></td>
                                        <td><?= $value['name'] ?></td>
                                        <td><?= $value['model'] ?></td>
                                        <td>
                                            <span class="border border-info" style="letter-spacing:.5rem"><?= $value['identification'] ?></span>
                                        </td>
                                    </tr>
                                <?php
                                }
                                ?>
                            </table>
                        </div>

                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        لیست سفرهای انجام شده توسط این راننده
                    </div>
                    <div class="card-body">
                        <div id="driverChart"></div>
                    </div>
                </div>
            </div>

            <div class="ms-Grid-col ms-sm12 ms-md12 ms-lg6">
                <div class="card">
                    <div class="card-header">
                        لیست نظرات دریافت کرده
                    </div>
                    <div class="card-body">
                        <ul class="d-flex flex-column align-items-center justify-content-center">
                            <?php
                            foreach ($comment as $key => $value) {
                            ?>
                                <li class="d-flex flex-row align-items-center justify-content-between" style="width:100%;">
                                    <span>شناسه سفر: #<?= $value['id'] ?>) <?= $value['comment'] ?></span>
                                </li>
                            <?php
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="ms-Grid-col ms-sm12 ms-md12 ms-lg6">
                <div class="card">
                    <div class="card-header">
                        ارسال پیامک به این راننده
                    </div>
                    <div class="card-body">
                        <form action="<?= URL ?>panel/driver/sms">
                            <input type="hidden" name="mobile" value="<?= $data['mobile'] ?>">
                            <textarea name="content" id="" style="height:100px;"></textarea>
                            <button>ارسال پیامک</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script type="text/javascript">
    // Load the Visualization API and the corechart package.
    google.charts.load('current', {
        'packages': ['corechart']
    });

    // Set a callback to run when the Google Visualization API is loaded.
    google.charts.setOnLoadCallback(drawChart);

    // Callback that creates and populates a data table,
    // instantiates the pie chart, passes in the data and
    // draws it.
    function drawChart() {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Status');
        data.addColumn('number', 'Count');
        data.addRows(<?= json_encode($driverRequestStatus) ?>);

        // Instantiate and draw our chart, passing in some options.
        var chart = new google.visualization.PieChart(document.getElementById('driverChart'));
        chart.draw(data, {
            width: '100%',
            height: 400,
            legend: 'top',
            colors: ['deeppink', '#045356', 'orange'],
            is3D: true,
            fontName: 'Vazir',
            legend: {
                alignment: 'center',
                position: 'right',
                textStyle: {
                    bold: true
                }
            }
        })
    }
</script>