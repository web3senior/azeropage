<?php
$data = $this->data['data']['data'];
$total = $this->data['data']['total'];
?>
<section>
    <div class="__frame" data-width="large">

        <?php
        if (isset($_GET['insert'])) {
            $insert = $_GET['insert'];
            if ($insert == 1)
                echo '<p class="alert alert-success">اضافه شد</p>';
            else
                echo '<p class="alert alert-danger">Err: ' . $_GET['msg'] . '</p>';
        }
        ?>
        <div class="ms-Grid-row">
            <div class="ms-Grid-col ms-sm12 ms-md12 ms-lg12">
                <div class="card">
                    <div class="card-header">
                        <ul class="d-flex justify-content-between align-items-center">
                            <li><?= $this->title ?></li>
                            <li>
                                <a href="javascript: " onclick="location.replace(location.pathname)">
                                    <i class="ms-Icon ms-Icon--Refresh" aria-hidden="true"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-blue table-alternate">
                                <caption></caption>
                                <thead>
                                    <th>عکس</th>
                                    <th>عنوان</th>
                                    <th>توضیحات</th>
                                    <th width="15%">عملیات</th>
                                </thead>
                                <?php
                                foreach ($data as $key => $value) {
                                    $id = $value['id'];
                                ?>
                                    <tr>
                                        <td class="d-flex align-items-center justify-content-center">
                                            <?php if ((empty($value['img']) || !file_exists('upload/images/' . $value['img']))) : ?>
                                                <span class="badge badge-dark badge-pill">بدون تصویر</span>
                                            <?php else : ?>
                                                <a target="_blank" href="<?= URL ?>upload/images/<?= $value['img'] ?>" class="btn-more">
                                                    <img src="<?= URL ?>upload/images/<?= $value['img'] ?>" style="width:40px;height:40px;border:1px solid var(--primary-color)" />
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= $value['title'] ?></td>
                                        <td><?= $value['description'] ?></td>
                                        <td>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <a href="javascript: " onclick="handleEdit(<?= $id ?>)"><?= ICON_EDIT ?></a>
                                                <a href="#" onclick="handleDelete(<?= $id ?>)"><?= ICON_DELETE ?></a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php
                                }
                                ?>
                            </table>
                        </div>
                        <?= (new Paging)->show(PATH_ADMIN . $this->endpoint, $total, $this->pg); ?>
                    </div>
                </div>
            </div>

            <div class="ms-Grid-col ms-sm12 ms-md12 ms-lg12" style="position:sticky;top:0">
                <div class="card">
                    <div class="card-header">عملیات</div>
                    <div class="card-body">
                        <form action="<?= URL ?>panel/<?= $this->endpoint ?>/insert" method="post" enctype="multipart/form-data" autocomplete="off">
                            <div>
                                عکس
                                <input type="hidden" name="img_hidden" value="">
                                <input class="form-control" type="file" name="img" id="img">
                            </div>
                            <div>
                                <label for="">عنوان</label>
                                <fluent-text-field appearance="filled" name="title"></fluent-text-field>
                            </div>

                            <div>
                                <label for="">توضیحات</label>
                                <textarea name="description" style="height: 200px;"></textarea>
                            </div>
                            <fluent-button appearance="accent" type="submit" id="btn-update" class="mt-10">اضافه</fluent-button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script type="text/javascript">
    const handleEdit = async (id) => {
        let result = await window.edit('<?= $this->endpoint ?>', id)
        document.querySelector('form').action = `<?= URL ?>panel/<?= $this->endpoint ?>/update/${id}`
        document.querySelector('fluent-button').innerText = "بروز رسانی"
        document.querySelector('[name="img_hidden"]').value = result.img
        document.querySelector('[name="title"]').value = result.title
        document.querySelector('[name="description"]').value = result.description
    }

    const handleDelete = (id) => {
        let answer = confirm(`آیا مطمئن به حذف رکورد مورد نظر هستید؟`)
        if (answer) window.location.href = `<?= URL ?>panel/<?= $this->endpoint ?>/delete?id=${id}`
    }
</script>