<section>
    <div class="__frame" data-width="large">

        <div class="ms-Grid-row">
            <div class="ms-Grid-col ms-sm12 ms-md12 ms-lg6">
                <div class="card">
                    <div class="card-header">
                        ابلاغ رای داوری
                    </div>
                    <div class="card-body">
                        <p>رسیدگی توسط خانم صادقی</p>
                        <a href="<?= URL ?>panel/legal">مشاهده این بخش</a>
                    </div>
                </div>
            </div>
            <div class="ms-Grid-col ms-sm12 ms-md12 ms-lg6">
                <div class="card">
                    <div class="card-header">
                        اجرای رای داوری
                    </div>
                    <div class="card-body">
                        <p>رسیدگی توسط آقای کریم زاده</p>
                        <a href="<?= URL ?>panel/legal2">مشاهده این بخش</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>