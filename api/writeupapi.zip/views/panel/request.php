<?php
$data = $this->data['data']['data'];
$total = $this->data['data']['total'];
$driver = $this->data['driver'];
?>
<section>
    <div class="__frame" data-width="large">

        <?php
        if (isset($_GET['insert'])) {
            $insert = $_GET['insert'];
            if ($insert == 1) {
        ?>
                <script>
                    Swal.fire({
                        title: 'با موفقیت ثبت شد',
                        icon: 'success',
                        confirmButtonText: 'بستن',
                        showCloseButton: true
                    })
                </script>
        <?php
            } else {
                echo '<p class="alert alert-danger">Err: ' . $_GET['msg'] . '</p>';
            }
        }
        ?>
        <div class="ms-Grid-row">
            <div class="ms-Grid-col ms-sm12 ms-md12 ms-lg12">
                <div class="card">
                    <div class="card-header">
                        <ul class="d-flex justify-content-between align-items-center">
                            <li><?= $this->title ?></li>
                            <li>
                                <a href="javascript: " onclick="location.replace(location.pathname)">
                                    <i class="ms-Icon ms-Icon--Refresh" aria-hidden="true"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <p class="alert alert--info">
                            برای مشاهده دقیق مبداء و مقصد روی نقشه، روی هر کدام کلیک کنید
                        </p>
                        <div class="table-responsive">
                            <table class="table table-blue table-alternate">
                                <caption></caption>
                                <thead>
                                    <th>ردیف</th>
                                    <th>نام و نام خانوادگی</th>
                                    <th>مسافت/ هزینه</th>
                                    <th>مبدا</th>
                                    <th>مقصد</th>
                                    <th>وضعیت</th>
                                    <th>راننده سفر</th>
                                    <th width="25%">عملیات</th>
                                </thead>
                                <?php
                                foreach ($data as $key => $value) {
                                    $id = $value['id'];
                                    switch ($value['status']) {
                                        case 'accepted':
                                            $statusText = '<span class="badge badge-success">پذیرفته شده</span>';
                                            break;
                                        case 'pending':
                                            $statusText = '<span class="badge badge-warning">در حال انتظار</span>';
                                            break;
                                        case 'cancelled':
                                            $statusText = '<span class="badge badge-danger">لغو شده</span>';
                                            break;
                                        case 'done':
                                            $statusText = '<span class="badge badge-success">اتمام سفر</span>';
                                            break;
                                        default:
                                            $statusText = 'مشخص نشده';
                                            break;
                                    }

                                ?>
                                    <tr>
                                        <td class="text-center"><?= ++$key ?></td>
                                        <td class="text-center">
                                            <?= $value['user_fullname'] ?>
                                            <br />
                                            <span class="badge badge-dark">شناسه سفر: <?= $value['id'] ?></span>
                                            <br />
                                            <small><?= $value['user_phone'] ?></small>
                                        </td>
                                        <td>
                                            مسافت:<?= $value['distance'] ?> کیلومتر
                                            <br />
                                            کرایه:<?= number_format($value['fare']) ?> ت
                                        </td>
                                        <td class="text-center" title="<?= json_decode($value['origin'])[0]->address ?>">
                                            <a target="_blank" href="https://maps.google.com/?q=<?= json_decode($value['origin'])[0]->lat ?>,<?= json_decode($value['origin'])[0]->lon ?>">
                                                <small>مشاهده مقصد</small>
                                            </a>
                                        </td>
                                        <td class="text-center" title="<?= json_decode($value['destination'])[0]->address ?>">
                                            <a target="_blank" href="https://maps.google.com/?q=<?= json_decode($value['destination'])[0]->lat ?>,<?= json_decode($value['destination'])[0]->lon ?>">
                                                <small>مشاهده مبداء</small>
                                            </a>
                                        </td>
                                        <td class="text-center"><?= $statusText ?></td>
                                        <td class="text-center">
                                            <?php
                                            if (!empty($value['driver_id'])) {
                                            ?>
                                                👮 <?= $value['driver_fullname'] ?>
                                                <br />
                                                <span class="badge badge-primary">شناسه راننده: <?= $value['driver_id'] ?></span>
                                            <?php
                                            } else {
                                            ?>
                                                تخصیص راننده:
                                                <input type="text" name="driver_id" id="" list="drivers">
                                                <datalist id="drivers">
                                                    <?php
                                                    foreach ($driver as $key => $value) {
                                                    ?>
                                                        <option>#<?= $value['id'] . ' ' . $value['fullname'] ?></option>
                                                    <?php
                                                    }
                                                    ?>
                                                </datalist>
                                                <button>به روز رسانی</button>
                                            <?php
                                            }
                                            ?>
                                        </td>
                                        <td>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <a href="<?= URL ?>panel/<?= $this->endpoint ?>/view?id=<?= $id ?>">
                                                    <span class="bage badge-pill badge-primary border border-primary"><?= ICON_PREVIEW ?></span>
                                                </a>
                                                <a href="javascript: " onclick="handleEdit(<?= $id ?>)"><?= ICON_EDIT ?></a>
                                                <a href="<?= URL ?>panel/<?= $this->endpoint ?>/delete?id=<?= $id ?>"><?= ICON_SMS ?></a>
                                                <a href="<?= URL ?>panel/<?= $this->endpoint ?>/status?id=<?= $id ?>&val=<?= ($status) ? '0' : '1' ?>"></a>
                                                <a href="#" onclick="handleDelete(<?= $id ?>)"><?= ICON_DELETE ?></a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php
                                }
                                ?>
                            </table>
                        </div>
                        <?= (new Paging)->show(PATH_ADMIN . $this->endpoint, $total, $this->pg); ?>
                    </div>
                </div>
            </div>

            <div class="ms-Grid-col ms-sm12 ms-md12 ms-lg12" style="position:sticky;top:0">
                <div class="card">
                    <div class="card-header">عملیات</div>
                    <div class="card-body">
                        <p class="alert alert--warning">
                            در صورت ثبت سفر توسط اپراتور، راننده نیز بایستی دستی توسط اپراتور انجام گردد.
                        </p>
                        <p class="alert alert--danger">
                            در صورتی که راننده و مسافر در سیستم تعریف نشده باشند، امکان ثبت سفر وجود ندارد.
                        </p>
                        <form action="<?= URL ?>panel/<?= $this->endpoint ?>/insert" method="post" enctype="multipart/form-data" autocomplete="off">
                            <div>
                                مبداء:
                                <div id="originMap" class="map"></div>
                            </div>
                            <div>
                                مقصد:
                                <div id="destinationMap" class="map"></div>
                            </div>
                            <div>
                                مسافت:
                                <fluent-text-field appearance="filled" name="distance"></fluent-text-field>
                            </div>
                            <div>
                                کرایه:
                                <fluent-text-field appearance="filled" name="fare"></fluent-text-field>
                            </div>
                            <div>
                                راننده:
                                <input type="text" name="driver_id" id="" list="drivers">
                                <datalist id="drivers">
                                    <?php
                                    foreach ($driver as $key => $value) {
                                    ?>
                                        <option>#<?= $value['id'] . ' ' . $value['fullname'] ?></option>
                                    <?php
                                    }
                                    ?>
                                </datalist>
                            </div>
                            <div>
                                <label for="">توضیحات</label>
                                <fluent-text-area appearance="filled" placeholder="" name="description" value="این سفر توسط اپراتور تعریف شده است."></fluent-text-area>
                            </div>

                            <fluent-button appearance="accent" type="submit" id="btn-update" class="mt-10">اضافه</fluent-button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script type="text/javascript">
    const handleEdit = async (id) => {
        let result = await window.edit('<?= $this->endpoint ?>', id)
        document.querySelector('form').action = `<?= URL ?>panel/<?= $this->endpoint ?>/update/${id}`
        document.querySelector('fluent-button').innerText = "بروز رسانی"
        document.querySelector('fluent-text-field[name="fullname"]').value = result.fullname
        document.querySelector('select[name="type"]').value = result.type
        document.querySelector('select[name="education_id"]').value = result.education_id
        document.querySelector('fluent-text-field[name="father_name"]').value = result.father_name
        document.querySelector('input[name="picture_hidden"]').value = result.picture
        document.querySelector('fluent-text-field[name="mobile"]').value = result.mobile
        document.querySelector('fluent-text-field[name="tel"]').value = result.tel
        document.querySelector('fluent-text-field[name="address"]').value = result.address
        document.querySelector('fluent-text-field[name="representitive"]').value = result.representitive
        document.querySelector('fluent-text-field[name="lawyer_date"]').value = result.lawyer_date
        document.querySelector('select[name="insurance"]').value = result.insurance
        document.querySelector('select[name="legal_issue"]').value = result.legal_issue
        document.querySelector('fluent-number-field[name="insurance_history"]').value = result.insurance_history
        document.querySelector('fluent-text-area[name="description"]').value = result.description
    }

    const handleDelete = (id) => {
        let answer = confirm(`آیا مطمئن به حذف رکورد مورد نظر هستید؟`)
        if (answer) window.location.href = `<?= URL ?>panel/<?= $this->endpoint ?>/delete?id=${id}`
    }
</script>


<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<style>
    .map {
        position: relative;
        height: 400px;
        border: 2px solid var(--primary-color)
    }

    .map:after {
        content: 'شهرستان اردبیل';
        position: absolute;
        right: 0;
        bottom: 0;
        background-color: var(--primary-color);
        color: #fff;
        padding: .2rem 1rem;
        font-family: var(--ff-vazir);
        z-index: 1000;
    }
</style>

<script type="text/javascript">
    const getAddressByLocation = async () => {
        var requestOptions = {
            method: 'GET',
            redirect: 'follow',
        }

        return await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${marker.getLatLng().lat}&lon=${marker.getLatLng().lng}&format=jsonv2&accept-language=fa`, requestOptions)
            .then((response) => response.json())
            .catch((error) => console.log('error', error))
    }
    // -----------------------------------
    let markerOption = L.icon({
        shadowUrl: null,
        drag: true,
        iconAnchor: new L.Point(12, 12),
        iconSize: new L.Point(25, 41),
        iconUrl: '<?= URL . UPLOAD_IMAGE_PATH . 'location_marker.png' ?>',
    })
    // -----------------------------------
    var originMap = new L.Map('originMap').setView([38.243063632250085, 48.29758857470783], 12)
    L.tileLayer('https://mt0.google.com/vt/lyrs=m&x={x}&y={y}&z={z}').addTo(originMap);
    var originMarker = new L.marker([38.243063632250085, 48.29758857470783], {
        icon: markerOption,
        draggable: true
    }).addTo(originMap)


    originMap.on('drag', (event) => originMarker.setLatLng(originMap.getCenter()))

    originMap.on('dragend', (event) => {
        setIsLoading(false)

        getAddressByLocation().then((result) => {
            console.log(result)
            setAddress([{
                address: `${result.address.city} - ${result.address.road !== undefined ? result.address.road + '-' : ''} ${result.name !== undefined ? result.name : ''}`,
                lat: result.lat,
                lon: result.lon
            }])
        })
    })

    // -----------------------------------
    var destinationMap = new L.Map('destinationMap').setView([38.243063632250085, 48.29758857470783], 12);
    L.tileLayer('https://mt0.google.com/vt/lyrs=m&x={x}&y={y}&z={z}').addTo(destinationMap);
    var destinationMarker = new L.marker([38.243063632250085, 48.29758857470783], {
        icon: markerOption,
        draggable: true
    }).addTo(destinationMap)
</script>