<section>
    <div class="__frame" data-width="small">
        <div class="ms-Grid">
            <div class="ms-Grid-row">
                <div class="ms-Grid-col ms-sm12">
                    <div id="msg"></div>
                    <div class="alert alert-info mt-10 border border-info">
                        <strong>Contact with developer:</strong>
                        <p>
                            <a href="mailto:web3senior@gmail.com" class="alert-link">web3senior@gmail.com</a>
                            <br/>
                            <a href="t.me/web3senior" class="alert-link">Telegram</a>
                        </p>
                    </div>
                </div>

            </div>
        </div>
</section>