<?php
$data = $this->data['data']['data'];
$total = $this->data['data']['total'];
$car = $this->data['car'];
?>
<section>
    <div class="__frame" data-width="xxxlarge">
        <?php
        if (isset($_GET['insert'])) {
            $insert = $_GET['insert'];
            if ($insert == 1)
                echo '<p class="alert alert-success">اضافه شد</p>';
            else
                echo '<p class="alert alert-danger">Err: ' . $_GET['msg'] . '</p>';
        }
        ?>
        <div class="ms-Grid-row">
            <div class="ms-Grid-col ms-sm12 ms-md12 ms-lg12">
                <div class="card">
                    <div class="card-header">
                        <ul class="d-flex justify-content-between align-items-center">
                            <li><?= $this->title ?></li>
                            <li>
                                <a href="javascript: " onclick="location.replace(location.pathname)">
                                    <i class="ms-Icon ms-Icon--Refresh" aria-hidden="true"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <div id="map"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<style>
    #map {
        position: relative;
        height: 60vh;
    }
    #map:after {
        content: 'شهرستان اردبیل';
        position: absolute;
        right: 0;
        bottom: 0;
        background-color: var(--primary-color);
        color: #fff;
        padding: .2rem 1rem;
        font-family: var(--ff-vazir);
        z-index: 1000;
    }
</style>
<script type="text/javascript">
    let cloudmadeUrl = 'https://mt0.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
        cloudmade = new L.TileLayer(cloudmadeUrl, {
            maxZoom: 19
        }),
        southWest = L.latLng(38.1798206357761, 48.21865389083308),
        northEast = L.latLng(38.30520008275403, 48.345629549549045),
        bounds = L.latLngBounds(southWest, northEast)


    var map = map = new L.Map('map', {
        zoomSnap: 0.5,
        maxBounds: bounds,
        fullscreenControl: true,
        layers: [cloudmade],
        center: new L.LatLng(38.243063632250085, 48.29758857470783),
        zoom: 14,
    })

    shapeLayerGroup = L.layerGroup().addTo(map)

    var marker = L.marker([51.5, -0.09]).addTo(map)

    let car = <?= json_encode($car) ?>;


    let carIcon = L.icon({
        iconUrl: `<?= URL . UPLOAD_IMAGE_PATH ?>car_icon_map.png`,
        iconSize: [50, 51],
        iconAnchor: [1, 1],
        popupAnchor: [25, 0],
    })

    car.forEach(item => {
        let shapeLayer = L.marker(item.location.split(','), {
            icon: carIcon
        }).addTo(shapeLayerGroup).bindPopup(item.name)
    });
</script>