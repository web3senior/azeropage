<?php
$data = $this->data['data']['data'];
$total = $this->data['data']['total'];
$food = $this->data['food'];
?>
<section>
    <div class="__frame" data-width="large">

        <?php
        if (isset($_GET['insert'])) {
            $insert = $_GET['insert'];
            if ($insert == 1) {
        ?>
                <script>
                    Swal.fire({
                        title: 'با موفقیت ثبت شد',
                        icon: 'success',
                        confirmButtonText: 'بستن',
                        showCloseButton: true
                    })
                </script>
        <?php
            } else {
                echo '<p class="alert alert-danger">Err: ' . $_GET['msg'] . '</p>';
            }
        }
        ?>
        <div class="ms-Grid-row">
            <div class="ms-Grid-col ms-sm12 ms-md12 ms-lg12">
                <div class="card">
                    <div class="card-header">جستجو</div>
                    <div class="card-body">
                        <form action="<?= URL ?>panel/<?= $this->endpoint ?>" method="get" autocomplete="off">
                            <div>
                                <label for="">نام</label>
                                <fluent-text-field appearance="filled" name="q_name" value="<?= (isset($_GET['q_fullname']) ? $_GET['q_fullname'] : '') ?>"></fluent-text-field>
                            </div>
                            <button appearance="accent" type="submit" id="btn-update">جستجو</button>
                        </form>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <ul class="d-flex justify-content-between align-items-center">
                            <li><?= $this->title ?></li>
                            <li>
                                <a href="javascript: " onclick="location.replace(location.pathname)">
                                    <i class="ms-Icon ms-Icon--Refresh" aria-hidden="true"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <output>

                        </output>
                        <div class="table-responsive">
                            <table class="table table-blue table-alternate">
                                <caption></caption>
                                <thead>
                                    <th>ردیف</th>
                                    <th>نام و نام خانوادگی</th>
                                    <th>موبایل</th>
                                    <th>آدرس</th>
                                    <th>جمع کل پرداختی</th>
                                    <th width="25%">عملیات</th>
                                </thead>
                                <?php
                                foreach ($data as $key => $value) {
                                    $id = $value['id'];
                                    $status = $value['status'];
                                    $statusText = ($status) ? ICON_ACTIVE : ICON_DEACTIVE;
                                ?>
                                    <tr>
                                        <td class="text-center"><?= ++$key ?></td>
                                        <td class="text-center"><?= $value['fullname'] ?></td>
                                        <td class="text-center"><?= $value['mobile'] ?></td>
                                        <td class="text-center"><?= $value['address'] ?></td>
                                        <td class="text-center"> <?= number_format(!empty($value['amount']) ? $value['amount'] : 0) ?></td>

                                        <td>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <a href="javascript: " onclick="showProduct(<?= $id ?>)">👀</a>
                                                <a href="javascript: " onclick="handleEdit(<?= $id ?>)"><?= ICON_EDIT ?></a>
                                                <a href="<?= URL ?>panel/<?= $this->endpoint ?>/status?id=<?= $id ?>&val=<?= ($status) ? '0' : '1' ?>"><?= $statusText ?></a>
                                                <a href="#" onclick="handleDelete(<?= $id ?>)"><?= ICON_DELETE ?></a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php
                                }
                                ?>
                            </table>
                        </div>
                        <?= (new Paging)->show(PATH_ADMIN . $this->endpoint, $total, $this->pg); ?>
                    </div>
                </div>
            </div>

            <div class="ms-Grid-col ms-sm12 ms-md12 ms-lg12">
                <div class="card">
                    <div class="card-header">عملیات</div>
                    <div class="card-body">
                        <form action="<?= URL ?>panel/<?= $this->endpoint ?>/insert" method="post" enctype="multipart/form-data" autocomplete="off">
                            <div>
                                دسته بندی: <a href="<?= URL . "panel/education" ?>"><span class="badge badge-pill badge-primary">ویرایش</span></a>
                                <select title="انتخاب کارمند" name="category_id">
                                    <?php
                                    foreach ($category as $key => $value) {
                                    ?>
                                        <option value="<?= $value['id'] ?>"><?= $value['name'] ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                            <div>
                                <label for="">نام</label>
                                <fluent-text-field appearance="filled" name="name"></fluent-text-field>
                            </div>
                            <div>
                                عکس
                                <input type="hidden" name="img_hidden" value="">
                                <input class="form-control" type="file" name="img" id="img">
                            </div>
                            <div>
                                <label for="">قیمت</label>
                                <fluent-number-field appearance="filled" name="price" dir="ltr"></fluent-text-field>
                            </div>
                            <div>
                                <label for="">توضیحات</label>
                                <textarea name="description"></textarea>
                            </div>
                            <fluent-button appearance="accent" type="submit" id="btn-update" class="mt-10">اضافه</fluent-button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script type="text/javascript">
    ClassicEditor
        .create(document.querySelector('[name="description"]'), {
            placeholder: 'توضیحات اضافه'
        })
        .then(editor => {
            window.editor = editor
        })
        .catch((e) => console.log)

    ClassicEditor
        .create(document.querySelector('[name="content"]'), {
            placeholder: ''
        })
        .then(editor => {
            window.contentEditor = editor
        })
        .catch((e) => console.log)


    const handleEdit = async (id) => {
        let result = await window.edit('<?= $this->endpoint ?>', id)
        document.querySelectorAll('form')[1].action = `<?= URL ?>panel/<?= $this->endpoint ?>/update/${id}`
        document.querySelector('fluent-button').innerText = "بروز رسانی"
        document.querySelector('[name="category_id"]').value = result.category_id
        document.querySelector('[name="name"]').value = result.name
        document.querySelector('[name="img_hidden"]').value = result.img
        document.querySelector('[name="price"]').value = result.price
        // document.querySelector('[name="description"]').value = result.description
        editor.setData(result.description)
    }

    const handleDelete = (id) => {
        let answer = confirm(`آیا مطمئن به حذف رکورد مورد نظر هستید؟`)
        if (answer) window.location.href = `<?= URL ?>panel/<?= $this->endpoint ?>/delete?id=${id}`
    }

    const showProduct = (id) => {
        var myHeaders = new Headers();

        var requestOptions = {
            method: 'GET',
            headers: myHeaders,
            redirect: 'follow'
        };

        document.querySelector('output').innerHTML =''

        fetch(`<?= URL ?>panel/<?= $this->endpoint ?>/fetchProduct/${id}`, requestOptions)
            .then(response => response.json())
            .then(result => {
                console.log(result)
                result.product.forEach((element, i) => {
                    document.querySelector('output').innerHTML += `
                    <ul>
                    <li>عکس محصول: <img src="<?= URL . UPLOAD_IMAGE_PATH ?>${element.img}" style="width:40px;height:40px;border:1px solid var(--primary-color)" /></li>
                    <li>نام محصول: ${element.name}</li>
                    <li>تعداد درخواستی: ${result.count[i]}</li>
                    </ul><hr/>
                    `
                })

            })
            .catch(error => console.log('error', error));
    }
</script>