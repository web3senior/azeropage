<?php
$data = $this->data['data']['data'];
$total = $this->data['data']['total'];
$education = $this->data['education'];
?>
<section>
    <div class="__frame" data-width="large">

        <?php
        if (isset($_GET['insert'])) {
            $insert = $_GET['insert'];
            if ($insert == 1) {
        ?>
                <script>
                    Swal.fire({
                        title: 'با موفقیت ثبت شد',
                        icon: 'success',
                        confirmButtonText: 'بستن',
                        showCloseButton: true
                    })
                </script>
        <?php
            } else {
                echo '<p class="alert alert-danger">Err: ' . $_GET['msg'] . '</p>';
            }
        }
        ?>
        <div class="ms-Grid-row">
            <div class="ms-Grid-col ms-sm12 ms-md12 ms-lg12">
                <div class="card">
                    <div class="card-header">
                        <ul class="d-flex justify-content-between align-items-center">
                            <li><?= $this->title ?></li>
                            <li>
                                <a href="javascript: " onclick="location.replace(location.pathname)">
                                    <i class="ms-Icon ms-Icon--Refresh" aria-hidden="true"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-blue table-alternate">
                                <caption></caption>
                                <thead>
                                    <th>ردیف</th>
                                    <th>نام و نام خانوادگی</th>
                                    <th>عکس</th>
                                    <th>موبایل</th>
                                    <th>تلفن</th>
                                    <th>موجودی</th>
                                    <th width="25%">عملیات</th>
                                </thead>
                                <?php
                                foreach ($data as $key => $value) {
                                    $id = $value['id'];
                                    $status = $value['status'];
                                    $statusText = ($status) ? ICON_ACTIVE : ICON_DEACTIVE;
                                    $gender = ($value['gender']) ? 'آقای' : 'خانم';
                                ?>
                                    <tr>
                                        <td class="text-center"><?= ++$key ?></td>
                                        <td><?= $gender ?> <?= $value['fullname'] ?></td>
                                        <td class="text-center">
                                            <?php if ((empty($value['picture']) || !file_exists('upload/images/' . $value['picture']))) : ?>
                                                <span class="badge badge-dark badge-pill">بدون تصویر</span>
                                            <?php else : ?>
                                                <a target="_blank" href="<?= URL ?>upload/images/<?= $value['picture'] ?>" class="btn-more">
                                                    <?= ICON_OPEN ?>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center"><?= $value['phone'] ?></td>
                                        <td class="text-center"><?= $value['tel'] ?></td>
                                        <td class="text-center"><?= number_format($value['wallet']) ?></td>
                                        <td>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <a href="<?= URL ?>panel/<?= $this->endpoint ?>/view?id=<?= $id ?>">
                                                    <span class="bage badge-pill badge-primary border border-primary"><?= ICON_PREVIEW ?></span>
                                                </a>
                                                <a href="<?= URL ?>panel/<?= $this->endpoint ?>/upload?user_id=<?= $id ?>" class="d-flex align-items-center justify-content-center bage badge-pill badge-warning border border-warning" style="column-gap:.5rem">
                                                    <?= ICON_UPLOAD ?>
                                                    <span>آپلود</span>
                                                    <span class="bage badge-pill badge-dark"><?= $value['user_upload_count'] ?></span>
                                                </a>
                                                <a href="javascript: " onclick="handleEdit(<?= $id ?>)"><?= ICON_EDIT ?></a>
                                                <a href="<?= URL ?>panel/<?= $this->endpoint ?>/delete?id=<?= $id ?>"><?= ICON_SMS ?></a>
                                                <a href="<?= URL ?>panel/<?= $this->endpoint ?>/status?id=<?= $id ?>&val=<?= ($status) ? '0' : '1' ?>"><?= $statusText ?></a>
                                                <a href="#" onclick="handleDelete(<?= $id ?>)"><?= ICON_DELETE ?></a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php
                                }
                                ?>
                            </table>
                        </div>
                        <?= (new Paging)->show(PATH_ADMIN . $this->endpoint, $total, $this->pg); ?>
                    </div>
                </div>
            </div>

            <div class="ms-Grid-col ms-sm12 ms-md12 ms-lg12" style="position:sticky;top:0">
                <div class="card">
                    <div class="card-header">عملیات</div>
                    <div class="card-body">
                        <div class="alert alert--warning">
                            بعد از ثبت مسافر اقدام به آپلود مدارک نمایید.
                        </div>
                        <form action="<?= URL ?>panel/<?= $this->endpoint ?>/insert" method="post" enctype="multipart/form-data" autocomplete="off">
                            <div>
                                <fluent-text-field appearance="filled" name="fullname">نام و نام خانوادگی</fluent-text-field>
                            </div>
                            <div>
                                مقطع تحصیلی: <a href="<?= URL . "panel/education" ?>"><span class="badge badge-pill badge-primary">ویرایش</span></a>
                                <select title="انتخاب کارمند" name="education_id">
                                    <?php
                                    foreach ($education as $key => $value) {
                                    ?>
                                        <option value="<?= $value['id'] ?>">#<?= $value['id'] . ' > ' . $value['name'] ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                            <div>
                                <fluent-text-field appearance="filled" name="father_name">نام پدر</fluent-text-field>
                            </div>
                            <div>
                                عکس
                                <input type="hidden" name="picture_hidden" value="">
                                <input class="form-control" type="file" name="picture" id="picture">
                            </div>
                            <div>
                                <label for="">موبایل</label>
                                <fluent-text-field appearance="filled" name="phone" dir="ltr"></fluent-text-field>
                            </div>
                            <div>
                                <label for="">تلفن</label>
                                <fluent-text-field appearance="filled" name="tel" dir="ltr"></fluent-text-field>
                            </div>
                            <div>
                                <fluent-text-field appearance="filled" name="address">آدرس</fluent-text-field>
                            </div>
                            <div>
                                <fluent-text-area appearance="filled" placeholder="" name="description">توضیحات</fluent-text-area>
                            </div>

                            <fluent-button appearance="accent" type="submit" id="btn-update" class="mt-10">اضافه</fluent-button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script type="text/javascript">
    const handleEdit = async (id) => {
        let result = await window.edit('<?= $this->endpoint ?>', id)
        document.querySelector('form').action = `<?= URL ?>panel/<?= $this->endpoint ?>/update/${id}`
        document.querySelector('fluent-button').innerText = "بروز رسانی"
        document.querySelector('fluent-text-field[name="fullname"]').value = result.fullname
        document.querySelector('select[name="type"]').value = result.type
        document.querySelector('select[name="education_id"]').value = result.education_id
        document.querySelector('fluent-text-field[name="father_name"]').value = result.father_name
        document.querySelector('input[name="picture_hidden"]').value = result.picture
        document.querySelector('fluent-text-field[name="phone"]').value = result.phone
        document.querySelector('fluent-text-field[name="tel"]').value = result.tel
        document.querySelector('fluent-text-field[name="address"]').value = result.address
        document.querySelector('fluent-text-area[name="description"]').value = result.description
    }

    const handleDelete = (id) => {
        let answer = confirm(`آیا مطمئن به حذف رکورد مورد نظر هستید؟`)
        if (answer) window.location.href = `<?= URL ?>panel/<?= $this->endpoint ?>/delete?id=${id}`
    }
</script>