<?php
$nav = [
    ['ViewDashboard', 'dashboard', 'پیشخوان'],
    ['Product', 'food', 'محصولات'],
    ['Location', 'category', 'دسته بندی'],
    ['Money', 'invoice', 'فاکتورها'],

    // ['Contact', 'user', 'مسافران'],
    // ['BranchCompare', 'request', 'سفرها'],
    // ['Taxi', 'car', 'خودروها'],

    // ['MapPin', 'trace', 'ردیابی'],
    // ['Slideshow', 'tour', 'تور'],
    // ['Money', 'service', 'امور مالی'],
    // ['SkypeMessage', 'service', 'پیامک'],
    // ['Settings', 'setting', 'تنظیمات'],
];
?>

<a href="<?= URL ?>" class="logo-link">
    <figure>
        <img alt='logo' src="<?= URL ?>logo.svg" draggable="false" className='animate fade' />
    </figure>
</a>

<ul>
    <?php
    foreach ($nav as $key => $value) {
    ?>
        <li className='animate blur'>
            <a id="<?= $value[1] ?>" class="nav-link" href="<?= URL . "panel/" . $value[1] ?>">
                <i class="ms-Icon ms-Icon--<?= $value[0] ?>" aria-hidden="true"></i>
                <span><?= $value[2] ?></span>
            </a>
        </li>
    <?php
    }
    ?>
</ul>

<a id="<?= $val[0] ?>" class="nav-link logout-link" href="<?= URL . "panel/logout" ?>">
    <i class="goldtext ms-Icon ms-Icon--SignOut" aria-hidden="true"></i>
    <span>خروج</span>
</a>